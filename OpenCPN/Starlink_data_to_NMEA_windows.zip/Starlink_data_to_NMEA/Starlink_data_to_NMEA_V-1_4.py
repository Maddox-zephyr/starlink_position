import subprocess
import time
import socket
import math
from collections import deque
from datetime import datetime, timezone

# --- CONFIGURATION ---
REPO_SCRIPT = r"starlink-grpc-tools-main\dish_grpc_text.py"

# This function should find the right ip adress to use
def get_target_ip():
    try:
        # Create a dummy socket connection to determine the local interface IP
        # We don't actually send data, just connect to a public DNS (Google's 8.8.8.8)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()

        # Split the IP into parts (e.g., ['192', '168', '1', '45'])
        ip_parts = local_ip.split('.')

        # Recombine the first three parts and add .255 at the end to broadcast to everyone
        target_ip = f"{ip_parts[0]}.{ip_parts[1]}.{ip_parts[2]}.255"
        
        return target_ip

    except Exception as e:
        return None, f"Error: {e}"




# UPDATE THIS TO MATCH THE TARGET COMPUTER IP
# If your ip cant be found change broadcast_IP to "youre ip adress"
# the second thing below is the UDP port. you can change that if you want, 
#it just needs to be any unused port and match youre setup with your nav software later
broadcast_IP = get_target_ip()
DESTINATION_BROADCAST = (broadcast_IP, 30330) 


INTERVAL = 1.5  #interval between position requests     
WINDOW_NAV = 9.0  # seconds to average cog and sog   

class NavCalculator:
    def __init__(self, window_seconds):
        self.window_seconds = window_seconds
        self.history = deque() #temporary storing nav data for averaging

    def add_point(self, lat, lon):
        now = time.time()
        self.history.append((now, lat, lon))

        #removing old averaging points
        while self.history and (now - self.history[0][0] > self.window_seconds):
            self.history.popleft()

    # this gets sog and cog averaged over 9 seconds
    def get_cog_sog(self):
        if len(self.history) < 2: return 0.0, 0.0
        t1, lat1, lon1 = self.history[0]
        t2, lat2, lon2 = self.history[-1]
        time_delta = t2 - t1
        if time_delta < 1: return 0.0, 0.0
        
        # Haversine Distance
        R = 6371000 
        phi1, phi2 = math.radians(lat1), math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlambda = math.radians(lon2 - lon1)
        a = math.sin(dphi/2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda/2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        dist = R * c
        
        #calculating cog
        y = math.sin(dlambda) * math.cos(phi2)
        x = math.cos(phi1) * math.sin(phi2) - math.sin(phi1) * math.cos(phi2) * math.cos(dlambda)
        cog = (math.degrees(math.atan2(y, x)) + 360) % 360

        # calculating speed
        speed_mps = dist / time_delta
        sog = speed_mps * 1.94384
        if sog < 0.3: #change this value if you want to change the cutoff value
            sog = 0.0
            cog = 0

        
        return cog, sog


def get_location_repo():
    try:
        # 0x08000000 hides the flashing window on Windows
        CREATE_NO_WINDOW = 0x08000000
        
        cmd = ["python", REPO_SCRIPT, "location"]
        
        result = subprocess.run(
            cmd, 
            capture_output=True, 
            text=True,
            encoding='utf-8',
            creationflags=CREATE_NO_WINDOW
        )

        if result.returncode != 0:
            print(f"DEBUG: Script Error -> {result.stderr}")
            return None

        # should remove errors from unexpected text
        lines = result.stdout.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            # We look for a line that has commas and numbers
            # Example: 2026-02-03T09:03:16,4.21...,100.60...,6.7...
            parts = line.split(',')
            
            # Must have at least 4 parts (Time, Lat, Lon, Alt)
            if len(parts) >= 4:
                try:
                    # Try to convert 2nd and 3rd parts to numbers. 
                    # If this fails (e.g. it's a text line), we just skip to the next line.
                    lat = float(parts[1])
                    lon = float(parts[2])
                    alt = float(parts[3])
                    
                    return {'lat': lat, 'lon': lon, 'alt': alt}
                except ValueError:
                    # if it wasn't a data line it skips it
                    continue
                    
        print(f"DEBUG: Data received but no valid CSV found. Raw output:\n{result.stdout[:100]}...")
        return None

    except Exception as e:
        print(f"DEBUG: System Error -> {e}")
        return None

#needed to attach the Checksum so that the nav software views it as valid
def create_nmea(payload):
    checksum = 0
    for char in payload:
        checksum ^= ord(char)
    return f"${payload}*{checksum:02X}\r\n"

def format_coord(val, is_lat):
    d = int(abs(val))
    m = (abs(val) - d) * 60
    s = f"{d * 100 + m:.4f}"
    if is_lat: dir = 'N' if val >= 0 else 'S'
    else: 
        dir = 'E' if val >= 0 else 'W'
        if d < 100: s = "0" + s
    return s, dir

def main():
    print(f"--- Starlink_Data_to_NMEA_V1.3 ---")
    print("If you encounter any problems ask for Finn in the big sailing groups.")
    print("You can find more information about the projekt on the following page:")
    print("https://maddox-zephyr.github.io/starlink_position/")
    print(f"Target: {DESTINATION_BROADCAST}")
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

    calc_nav = NavCalculator(WINDOW_NAV)

    while True:
        data = get_location_repo()
        
        if data:
            calc_nav.add_point(data['lat'], data['lon'])
            cog_nav, sog_nav = calc_nav.get_cog_sog()
            
            now = datetime.now(timezone.utc).strftime("%H%M%S")
            lat_s, lat_d = format_coord(data['lat'], True)
            lon_s, lon_d = format_coord(data['lon'], False)

            #this is where we create the actual NMEA strings
            msgs = []
            msgs.append(create_nmea(f"GPGGA,{now},{lat_s},{lat_d},{lon_s},{lon_d},1,08,1.0,{data['alt']:.1f},M,0.0,M,,"))
            msgs.append(create_nmea(f"GPVTG,{cog_nav:.1f},T,,M,{sog_nav:.2f},N,,K,A"))

            for msg in msgs:
                try:
                    payload = msg.encode('utf-8')
                    sock.sendto(payload, DESTINATION_BROADCAST)
                except Exception as e:
                    print(f"Send Error: {e}")

            print(f"Sent: {data['lat']:.4f}, {data['lon']:.4f} | SOG: {sog_nav:.1f}kn, COG: {cog_nav:.0f}°")
        else:
            print(".", end="", flush=True)
        
        time.sleep(INTERVAL)

if __name__ == "__main__":
    main()