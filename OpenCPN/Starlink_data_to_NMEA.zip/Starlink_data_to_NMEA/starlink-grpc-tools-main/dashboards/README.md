This directory contains user-contributed dashboards for use with the data collected by the scripts in this project.

If you have built a dashboard you think is useful, please consider filing a pull request to have it added here.

Alternatively, just post it anywhere and update the [Dashboards Wiki article](https://github.com/sparky8512/starlink-grpc-tools/wiki/Dashboards) to point to it. This project's Wiki is configured to be editable by anyone with a GitHub login, so no special permissions are needed for doing so.
